﻿using System;
using System.Text;
using System.Windows.Forms;

namespace projeto_Bilheteria
{
    internal class Bilheteria
    {
        private char[,] assentos = new char[15, 40];
        private Random random = new Random();

        public Bilheteria()
        {
            for (int i = 0; i < assentos.GetLength(0); i++)
            {
                for (int j = 0; j < assentos.GetLength(1); j++)
                {
                    assentos[i, j] = '.';
                }
            }
        }

        public string MostrarAssentos()
        {
            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < assentos.GetLength(0); i++)
            {
                for (int j = 0; j < assentos.GetLength(1); j++)
                {
                    sb.Append(assentos[i, j]).Append(' ');
                }
                sb.AppendLine();
            }

            sb.AppendLine()
              .Append(". = Livre | # = Reservado");

            return sb.ToString();
        }

        public void ReservarAssento(str
